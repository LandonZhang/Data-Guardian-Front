<template>
  <el-button type="primary" @click="searchRules">搜索</el-button>
</template>

<script lang="ts" setup>
import axios from 'axios'
import { ElMessage } from 'element-plus'
import { watch } from 'vue';





// 定义响应数据中每条规则的结构
interface RuleData {
  id: number;
  project_name: string;
  table_name: string;
  feature_name: string;
  rule_content: string;
  error_type: string;
  issue_details: string | null;
  created_at: string;
}

// 定义父组件传入的参数，所有参数均以对应变量名继承
const props = defineProps<{
  select_project: string[],
  selected_table: string[],
  selected_feature: string[],
  start_time: string,
  end_time: string,
  page: number
}>()

// 将数组解析为特定格式的字符串
// 例如：select_project => project_name="测试项目33"&project_name="测试项目4"
const projectNameStr = props.select_project
  .map(item => `project_name=${item}`)
  .join('&')

const tableNameStr = props.selected_table
  .map(item => `table_name=${item}`)
  .join('&')

const featureNameStr = props.selected_feature
  .map(item => `feature_name=${item}`)
  .join('&')


//只有分页参数（即 props.page）的变化时才自动调用 searchRules
watch(() => props.page, (newPage, oldPage) => {
  if (newPage !== oldPage) {
    searchRules();
  }
});

// 固定每页数据量
const PAGE_SIZE = 12
// 通过 emit 将搜索结果返回给父组件（其他子组件可共享该数据）
const emit = defineEmits<{
  (e: 'update:tableData', data: RuleData[]): void,
  (e: 'update:total', total: number): void
}>()

async function searchRules() {

  // 构造请求参数
  const params: any = {
    project_name: projectNameStr,
    table_name: tableNameStr,
    feature_name: featureNameStr,
    start_time: props.start_time,
    end_time: props.end_time,
    page: props.page,
    page_size: PAGE_SIZE
  };

  try {
    const response = await axios.get('http://127.0.0.1:8080/rule/search/', { params });
    const responseData = response.data;
    emit('update:tableData', responseData.data);
    emit('update:total', responseData.total);
  } catch (error: any) {
    console.error('搜索规则失败', error);
    ElMessage.error('搜索规则失败');
  }

}

</script>
